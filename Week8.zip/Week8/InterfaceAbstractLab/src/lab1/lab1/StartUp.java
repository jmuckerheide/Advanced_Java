package lab1;

public class StartUp {
    public static void main(String args[]){
        SuperClass objectName = new AdvancedJavaCourse("courseName", "courseNumber");
        objectName.setCredits(4.0);
        objectName.setPrerequisites("Prerequisites");
        System.out.println(objectName.getCourseName() + objectName.getCourseNumber() + objectName.getCredits() + objectName.getPrerequisites());
    }
}
