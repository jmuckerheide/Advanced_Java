package lab1;

import javax.swing.JOptionPane;

/**
 * Describe responsibilities here.
 *
 * @author      Joshua Muckerheide
 * @version     1.00
 */
public class AdvancedJavaCourse extends lab1.SuperClass {

    public AdvancedJavaCourse(String courseName, String courseNumber) {
        this.setCourseName(courseName);
        this.setCourseNumber(courseNumber);
    }
    
}
