package lab2;

public class StartUp {
    public static void main(String args[]){
        Common objectName = new AdvancedJavaCourse("courseName", "courseNumber");
        objectName.setCredits(4.0);
        objectName.setPrerequisites("Prerequisites");
        System.out.println(objectName.getCourseName() + objectName.getCourseNumber() + objectName.getCredits() + objectName.getPrerequisites());
    }
}
