package lab2;

public class example implements  Common {
    @Override
    public String getCourseNumber() {
        return null;
    }

    @Override
    public double getCredits() {
        return 0;
    }

    @Override
    public String getPrerequisites() {
        return null;
    }

    @Override
    public String getCourseName() {
        return null;
    }

    @Override
    public void setCourseNumber(String courseNumber) {

    }

    @Override
    public void setCredits(double credits) {

    }

    @Override
    public void setPrerequisites(String prerequisites) {

    }

    @Override
    public void setCourseName(String courseName) {

    }
}
