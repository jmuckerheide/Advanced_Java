package lab2;
public interface Common {

    String getCourseNumber();
    double getCredits();
    String getPrerequisites();
    String getCourseName();
    void setCourseNumber(String courseNumber);
    void setCredits(double credits);
    void setPrerequisites(String prerequisites);
    void setCourseName(String courseName);
}