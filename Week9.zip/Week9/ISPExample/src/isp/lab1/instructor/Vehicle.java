package isp.lab1.instructor;

public interface Vehicle {

    public void start();
    public void drive(int distance);
    public void stopByBreaking();


}
